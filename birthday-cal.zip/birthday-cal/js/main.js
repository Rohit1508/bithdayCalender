class BirthDayCalender { }
BirthDayCalender.prototype.resetCalender = () => {
    let week = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    week.forEach(day => {
        let dayElement = document.getElementById(day);
        dayElement.classList.remove('day--empty');
        dayElement = dayElement.getElementsByClassName('day__people');
        dayElement[0].innerHTML = null;
    });
}
BirthDayCalender.prototype.update = () => {
    birthDayCalender.resetCalender();
    const sun = [], mon = [], tue = [], wed = [], thu = [], fri = [], sat = [];
    const dayWiseData = [sun, mon, tue, wed, thu, fri, sat];
    const inputData = JSON.parse(document.getElementById('json-input').textContent);
    const inputYear = document.getElementById('year').value;
    const currentYearData = inputData.filter(function (day) {
        return new Date(day.birthday).getFullYear() == inputYear;
    })
    currentYearData.forEach(element => {
        const day = new Date(element.birthday).getDay();
        const month = new Date(element.birthday).getMonth();
        const date = new Date(element.birthday).getDate();
        element.age = (date / 31) + month;
        dayWiseData[day].push(element);
    });
    birthDayCalender.fillCalender(dayWiseData);
}
BirthDayCalender.prototype.sizeOfBlock = (dayWiseData) => {
    let birthdayCount = dayWiseData.length;
    let size = Math.sqrt(birthdayCount);
    size = (100 / Math.ceil(size));
    return size + '%';
}
BirthDayCalender.prototype.sortByAge = (dayWiseData) => {
    return dayWiseData.sort((a, b) => {
        return a.age - b.age;
    })
}
BirthDayCalender.prototype.displayBirthday = (dayWiseData, day, size) => {
    for (let j = 0; j < dayWiseData.length; j++) {
        let name = (dayWiseData[j].name.substr(0, 2)).toUpperCase();
        let blockTemplate = `<div class="day__person">${name}</div>`;
        let dayPeople = day.getElementsByClassName('day__people');
        dayPeople[0].innerHTML += blockTemplate;
        dayPeople[0].getElementsByClassName('day__person')[j].style.float = 'left';
        dayPeople[0].getElementsByClassName('day__person')[j].style.width = size;
        dayPeople[0].getElementsByClassName('day__person')[j].style.height = size;
    }
}
BirthDayCalender.prototype.fillCalender = (dayWiseData) => {
    let size;
    const week = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    for (let i = 0; i < week.length; i++) {
        let day = document.getElementById(week[i]);
        size = birthDayCalender.sizeOfBlock(dayWiseData[i]);
        if (dayWiseData[i].length > 0) {
            dayWiseData[i] = birthDayCalender.sortByAge(dayWiseData[i]);
            birthDayCalender.displayBirthday(dayWiseData[i], day, size);
        }
        else {
            day.classList.add('day--empty');
        }
    }
}

let birthDayCalender = new BirthDayCalender();
(function () {
    let update = document.getElementById('update');
    update.addEventListener('click', birthDayCalender.update);
})();
